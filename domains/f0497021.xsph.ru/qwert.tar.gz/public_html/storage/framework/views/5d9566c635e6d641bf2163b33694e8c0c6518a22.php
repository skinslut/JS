<?php $__env->startSection('title', 'Добро пожаловать!'); ?>

<?php $__env->startSection('content'); ?>
        <a class="mb-3" href="<?php echo e(route('login')); ?>">Войти</a>
        <a class="mb-3" href="<?php echo e(route('register')); ?>">Зарегистрироваться</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f0497021/domains/f0497021.xsph.ru/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>