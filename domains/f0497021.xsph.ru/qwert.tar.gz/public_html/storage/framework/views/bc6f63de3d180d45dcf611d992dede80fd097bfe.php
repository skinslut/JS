<div class="d-flex w-100">
    <a <?php echo e($paginator->previousPageUrl() ? "href={$paginator->previousPageUrl()}" : ''); ?> class="mr-2 w-50" <?php echo e($paginator->currentPage() === $paginator->firstItem() ? 'disabled' : ''); ?>>Назад</a>
    <a <?php echo e($paginator->nextPageUrl() ? "href={$paginator->nextPageUrl()}": ''); ?> class="ml-2 w-50" <?php echo e($paginator->currentPage() === $paginator->lastPage() ? 'disabled' : ''); ?>>Вперед</a>
</div>

<?php /**PATH /home/rydal/Projects/js-tests/resources/views/widgets/paginator.blade.php ENDPATH**/ ?>