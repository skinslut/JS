<?php $__env->startSection('title', 'Домашняя страница'); ?>

<?php $__env->startSection('content'); ?>
        <a class="mb-3" href="<?php echo e(route('test.init')); ?>">Пройти тест</a>
        <a class="mb-3" href="<?php echo e(route('view-result.home')); ?>">Мои результаты</a>
        <form action="<?php echo e(route('logout')); ?>" class="w-100 d-flex justify-content-center" method="POST">
            <?php echo csrf_field(); ?>
            <button class="mb-3">Выйти</button>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f0497021/domains/f0497021.xsph.ru/public_html/resources/views/home.blade.php ENDPATH**/ ?>