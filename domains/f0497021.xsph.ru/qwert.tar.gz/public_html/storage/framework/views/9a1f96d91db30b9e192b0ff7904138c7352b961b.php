<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>JS тест | <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->

    <!-- Fonts -->

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="content-wrapper <?php echo $__env->yieldContent('content-wrapper-class'); ?>">
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/rydal/Projects/js-tests/resources/views/layouts/app.blade.php ENDPATH**/ ?>