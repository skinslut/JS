<?php $__env->startSection('title', 'Мои результаты'); ?>

<?php $__env->startSection('content'); ?>
    <table class="table ">
        <thead>
            <tr class=" text-left text-muted" >
                <th style="vertical-align: top !important;">Верных ответов</th>
                <th style="vertical-align: top !important;">Статус</th>
                <th style="vertical-align: top !important;">Дата</th>
            </tr>
        </thead>
        <?php if($resultsPaginator->total()): ?>
            <tbody class="text-left">
                <?php $__currentLoopData = $resultsPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                        <td><?php echo e($result->rating); ?> \ 25</td>
                        <td><?php echo e($result->display_state); ?></td>
                        <td><?php echo e($result->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php else: ?>
            <tbody class="text-left">
                <tr>
                    <td colspan="100%">У вас пока нет пройденных тестов</td>
                </tr>
            </tbody>
        <?php endif; ?>
    </table>
    <?php if($resultsPaginator->total()): ?>
        <?php echo e($resultsPaginator->links('widgets.paginator')); ?>

    <?php endif; ?>
    <a href="<?php echo e(route('home')); ?>" class="mx-auto mt-4">На главную</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f0497021/domains/f0497021.xsph.ru/public_html/resources/views/view-result/home.blade.php ENDPATH**/ ?>