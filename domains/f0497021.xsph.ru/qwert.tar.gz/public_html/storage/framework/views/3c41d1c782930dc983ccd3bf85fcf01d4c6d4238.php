<?php $__env->startSection('title', $question->theme->name); ?>
<?php $__env->startSection('content-wrapper-class', 'content-wrapper_test-bg'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('test.answer', $question)); ?>" class="form" method="post" name="test-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="ANSWER">
        <div class="timer mb-5" id="timer">
            <span>02</span>:<span>00</span>
        </div>
        <div class="test__info mb-5">
            <h1 class="mb-4">Тема: "<?php echo e($question->theme->name); ?>"</h1>
            <h2><?php echo e($question->text); ?></h2>
        </div>

        <?php
            $answers = $question->answers;
            shuffle($answers)
        ?>

        <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <input type="radio" name="answer" id="<?php echo e($index); ?>" value="<?php echo e($answer); ?>" <?php echo e($index === 0 ? 'checked' : ''); ?>/>
                <label for="<?php echo e($index); ?>"><?php echo e($answer); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-5"></div>
        <div class="form-group">
            <input type="submit" class="mx-auto" name="SUBMITTED" value="Отправить ответ">
        </div>
    </form>

    <script>
        let target_date = new Date();
        let days, hours, minutes, seconds;
        let countdown = document.getElementById("timer");


        target_date = target_date.getTime() + 1000 * 120;

        getCountdown();

        setInterval(function () { getCountdown(); }, 1000);

        function getCountdown(){

            let current_date = new Date().getTime();
            let seconds_left = (target_date - current_date) / 1000;

            minutes = parseInt(seconds_left / 60);
            seconds = parseInt( seconds_left % 60 );

            if (!minutes && !seconds) {
                let form = document.forms['test-form'];

                form.submit();
            }

            countdown.innerHTML = "<span>" + pad(minutes) + "</span>:<span>" + pad(seconds) + "</span>";
        }

        function pad(n) {
            return (n < 10 ? '0' : '') + n;
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rydal/Projects/js-tests/resources/views/tests/index.blade.php ENDPATH**/ ?>