<?php


namespace App\TestsCore;


use Exception;
use Throwable;

class TestsException extends Exception
{
}
